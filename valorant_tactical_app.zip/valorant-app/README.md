# 无畏契约战术手册 APP

> VALORANT 全维度战术攻略 PWA 应用

## 📱 安装方式

### 手机端（推荐）
1. 用浏览器打开 `index.html` 所在的网址
2. **iPhone (Safari)**：点击分享 → "添加到主屏幕"
3. **Android (Chrome)**：地址栏会出现 "安装" 图标，点击即可
4. 也可以点击APP内的 "📲 安装" 按钮

### 电脑端
1. Chrome/Edge 打开后，地址栏右侧会出现安装图标 📥
2. 点击即可安装为桌面应用

### 本地运行
由于 Service Worker 需要 HTTP 协议，不能直接 file:// 打开，需启动一个本地服务器：

```bash
# Python 3
python3 -m http.server 8080

# Node.js
npx serve .
```

然后访问 `http://localhost:8080`

## 📂 文件结构

```
valorant-app/
├── index.html       # 主页面（APP入口）
├── manifest.json    # PWA 配置文件
├── sw.js            # Service Worker（离线缓存）
├── splash.svg       # 启动屏
├── icons/           # APP 图标
│   ├── icon-192.png
│   ├── icon-384.png
│   └── icon-512.png
└── README.md
```

## 🎮 功能模块

| 模块 | 说明 |
|------|------|
| 首页 | 版本概览、强势特工TOP5、竞技地图池 |
| 地图攻略 | 13张地图详情，支持筛选 |
| 特工推荐 | 29位特工S-D梯度，支持搜索和角色筛选 |
| 武器数据 | 18把武器全参数，分类筛选 |
| 战术指南 | 爆弹/默认/假打/慢摸 四大战术 |
| 经济管理 | 经济计算器 + 策略速查 |
| 瞄准训练 | 反应速度训练器，统计命中率/反应时间 |

## 📊 数据版本

- Season 2026 Act 4 (Patch 13.00)
- 数据仅供参考，版本更新后请以游戏内为准

## 🔧 技术栈

- 纯 HTML/CSS/JS，零依赖
- PWA (Progressive Web App)
- Service Worker 离线缓存
- 响应式设计，适配手机/平板/桌面
